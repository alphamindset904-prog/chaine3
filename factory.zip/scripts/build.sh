#!/usr/bin/env bash
# usage: build.sh STORY [test|rapide|complete]
set -euo pipefail
STORY="$1"; MODE="${2:-rapide}"
[[ "$STORY" =~ ^[a-z0-9_-]+$ ]] || { echo "Nom d'histoire invalide : $STORY"; exit 1; }
[ -d "stories/$STORY" ] || { echo "Dossier stories/$STORY introuvable"; exit 1; }
W="work/$STORY"; rm -rf "$W"; mkdir -p "$W"; cp -r template/. "$W/"
[ -d "stories/$STORY/src" ] && cp -r "stories/$STORY/src/." "$W/src/"

echo "== 1/4 Voix (Piper)"
python3 scripts/tts.py "stories/$STORY" "$W/shots_wav"
python3 scripts/assemble_voice.py "stories/$STORY/SHOTS.txt" "$W/shots_wav" "$W"

echo "== 2/4 Installation des outils vidéo"
cd "$W"; npm install --no-audit --no-fund

echo "== 3/4 Rendu ($MODE)"
mkdir -p out
EXTRA=""; [ "$MODE" = "test" ] && EXTRA="--frames=0-89"
[ "$MODE" != "complete" ] && export REMOTION_FAST=1
npx remotion render src/index.jsx Story out/silent.mp4 --gl=swangle --concurrency="$(nproc)" \
  --image-format=jpeg --jpeg-quality=90 --crf=20 $EXTRA

echo "== 4/4 Ajout de la voix"
ffmpeg -y -hide_banner -loglevel error -i out/silent.mp4 -i voiceover.wav -map 0:v -map 1:a \
  -c:v copy -c:a aac -b:a 192k -shortest final.mp4
ls -la final.mp4
