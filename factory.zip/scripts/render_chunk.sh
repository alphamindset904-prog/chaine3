#!/usr/bin/env bash
# usage: render_chunk.sh STORY MODE CHUNK NCHUNKS   -> rend une tranche d'images dans work/STORY/out/part_XX.mp4
set -euo pipefail
STORY="$1"; MODE="$2"; I="$3"; N="$4"
cd "work/$STORY"
FR=$(python3 -c "import json;d=json.load(open('src/timing.json'));print(int(d['duration']*30+0.5))")
if [ "$MODE" = "test" ]; then
  [ "$I" = "0" ] || { echo "mode test : tranche $I ignorée"; exit 0; }
  START=0; END=89
else
  START=$(( I * FR / N )); END=$(( (I + 1) * FR / N - 1 ))
fi
[ "$START" -le "$END" ] || { echo "tranche vide"; exit 0; }
echo "Tranche $I : images $START à $END sur $FR"
npm install --no-audit --no-fund
mkdir -p out
[ "$MODE" != "complete" ] && export REMOTION_FAST=1
npx remotion render src/index.jsx Story "out/part_$(printf %02d "$I").mp4" --gl=swangle --concurrency="$(nproc)" \
  --codec=h264 --pixel-format=yuv420p --image-format=jpeg --jpeg-quality=90 --crf=20 --frames="$START-$END"
