#!/usr/bin/env python3
"""Assemble les audios par plan en voiceover.wav et écrit timing.json (mêmes champs que prepare_voice.py).
usage: assemble_voice.py SHOTS.txt WAV_DIR PROJECT_DIR [--gap 0.38] [--speed 1.08]"""
import argparse, json, os, subprocess, sys

def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode: sys.exit(r.stderr[-800:])
    return r.stdout

def dur(p):
    return float(run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', p]).strip())

ap = argparse.ArgumentParser()
ap.add_argument('shots'); ap.add_argument('wavs'); ap.add_argument('project')
ap.add_argument('--gap', type=float, default=0.38); ap.add_argument('--speed', type=float, default=1.08)
ap.add_argument('--lead', type=float, default=0.15); ap.add_argument('--tail', type=float, default=0.8)
a = ap.parse_args()

shots = []
for line in open(a.shots, encoding='utf-8'):
    if '|' in line:
        k, t = line.split('|', 1); shots.append((k.strip(), t.strip()))
tmp = os.path.join(a.wavs, '_n'); os.makedirs(tmp, exist_ok=True)

def silence(name, d):
    p = os.path.join(tmp, name)
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo',
         '-t', f'{d:.3f}', '-c:a', 'pcm_s16le', p])
    return p

parts, out, t = [silence('lead.wav', a.lead)], [], a.lead
for i, (k, txt) in enumerate(shots):
    n = os.path.join(tmp, f'{k}.wav')
    run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', os.path.join(a.wavs, f'{k}.wav'),
         '-af', f'atempo={a.speed},aresample=48000', '-ac', '2', '-c:a', 'pcm_s16le', n])
    d = dur(n); parts.append(n)
    out.append(dict(key=k, start=round(t, 3), end=round(t + d, 3), words=len(txt.split()), text=txt))
    t += d
    if i < len(shots) - 1:
        parts.append(silence(f'gap{i}.wav', a.gap)); t += a.gap
parts.append(silence('tail.wav', a.tail))
lst = os.path.join(tmp, 'list.txt')
open(lst, 'w').write(''.join(f"file '{os.path.abspath(p)}'\n" for p in parts))
os.makedirs(a.project, exist_ok=True)
run(['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst,
     '-ar', '48000', '-ac', '2', os.path.join(a.project, 'voiceover.wav')])
os.makedirs(os.path.join(a.project, 'src'), exist_ok=True)
timing = dict(fps=30, duration=round(out[-1]['end'] + 0.75, 2), shots=out)
json.dump(timing, open(os.path.join(a.project, 'src', 'timing.json'), 'w'), indent=1, ensure_ascii=False)
print(f"{len(shots)} plans, {timing['duration']} s")
