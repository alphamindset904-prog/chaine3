#!/usr/bin/env bash
# usage: finish.sh STORY   -> colle les tranches (work/STORY/out/part_*.mp4) et ajoute la voix
set -euo pipefail
STORY="$1"; cd "work/$STORY"
ls out/part_*.mp4 >/dev/null 2>&1 || { echo "Aucune tranche trouvée"; exit 1; }
for f in $(ls out/part_*.mp4 | sort); do echo "file '$(pwd)/$f'"; done > out/list.txt
ffmpeg -y -hide_banner -loglevel error -f concat -safe 0 -i out/list.txt -c copy out/silent.mp4
ffmpeg -y -hide_banner -loglevel error -i out/silent.mp4 -i voiceover.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest final.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 final.mp4
ls -la final.mp4
