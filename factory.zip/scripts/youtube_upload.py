#!/usr/bin/env python3
"""Envoie une vidéo sur YouTube. usage: youtube_upload.py VIDEO.mp4 meta.json [DATE_PUBLICATION]
DATE_PUBLICATION (UTC, ex 2026-11-15T18:00:00Z) : la vidéo est envoyée en privé puis YouTube la rend publique à cette date.
Variables : YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN. Par défaut la vidéo reste PRIVÉE."""
import json, os, sys
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

video, metaf = sys.argv[1], sys.argv[2]
meta = json.load(open(metaf, encoding='utf-8'))
publish_at = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] else meta.get('publish_at')
creds = Credentials(None, refresh_token=os.environ['YT_REFRESH_TOKEN'],
                    token_uri='https://oauth2.googleapis.com/token',
                    client_id=os.environ['YT_CLIENT_ID'], client_secret=os.environ['YT_CLIENT_SECRET'],
                    scopes=['https://www.googleapis.com/auth/youtube.upload'])
yt = build('youtube', 'v3', credentials=creds)
body = dict(snippet=dict(title=meta['title'][:100], description=meta.get('description', ''),
                         tags=meta.get('tags', []), categoryId='27', defaultLanguage='fr'),
            status=dict(privacyStatus=meta.get('privacy', 'private'), selfDeclaredMadeForKids=False))
if publish_at:
    body['status']['privacyStatus'] = 'private'
    body['status']['publishAt'] = publish_at
req = yt.videos().insert(part='snippet,status', body=body, media_body=MediaFileUpload(video, resumable=True))
resp = None
while resp is None:
    st, resp = req.next_chunk()
    if st: print(f'{int(st.progress()*100)} %')
print('Envoyée : https://youtube.com/watch?v=' + resp['id'], ('(programmée le ' + publish_at + ')') if publish_at else ('(privé)' if body['status']['privacyStatus'] == 'private' else ''))
