#!/usr/bin/env bash
# usage: prep.sh STORY   -> prépare work/STORY (décors + voix + timing)
set -euo pipefail
STORY="$1"
[[ "$STORY" =~ ^[a-z0-9_-]+$ ]] || { echo "Nom d'histoire invalide : $STORY"; exit 1; }
[ -d "stories/$STORY" ] || { echo "Dossier stories/$STORY introuvable"; exit 1; }
W="work/$STORY"; rm -rf "$W"; mkdir -p "$W"; cp -r template/. "$W/"
[ -d "stories/$STORY/src" ] && cp -r "stories/$STORY/src/." "$W/src/"
python3 scripts/tts.py "stories/$STORY" "$W/shots_wav"
python3 scripts/assemble_voice.py "stories/$STORY/SHOTS.txt" "$W/shots_wav" "$W"
rm -rf "$W/shots_wav"
python3 -c "import json;d=json.load(open('$W/src/timing.json'));print('IMAGES:',int(d['duration']*30+0.5))"
