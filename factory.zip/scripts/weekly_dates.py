#!/usr/bin/env python3
"""Affiche les dates de publication, une par semaine. usage: weekly_dates.py 2026-11-15T18:00:00Z 10"""
import sys
from datetime import datetime, timedelta, timezone
d = datetime.strptime(sys.argv[1], '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
for i in range(int(sys.argv[2])):
    print(i + 1, (d + timedelta(weeks=i)).strftime('%Y-%m-%dT%H:%M:%SZ'))
