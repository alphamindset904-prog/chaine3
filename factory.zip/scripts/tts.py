#!/usr/bin/env python3
"""Génère un fichier audio par plan avec Piper (voix libre, gratuite).
usage: tts.py STORY_DIR OUT_DIR   (lit STORY_DIR/SHOTS.txt et STORY_DIR/meta.json)"""
import json, os, subprocess, sys, urllib.request

def voice_files(voice, cache):
    lang_region, name, quality = voice.split('-')
    lang = lang_region.split('_')[0]
    base = f'https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0/{lang}/{lang_region}/{name}/{quality}/{voice}'
    os.makedirs(cache, exist_ok=True)
    for ext in ('.onnx', '.onnx.json'):
        dst = os.path.join(cache, voice + ext)
        if not os.path.exists(dst):
            print('download', base + ext, flush=True)
            urllib.request.urlretrieve(base + ext, dst)
    return os.path.join(cache, voice + '.onnx')

def synth(model, text, out):
    for flag in ('-f', '--output_file'):
        r = subprocess.run([sys.executable, '-m', 'piper', '-m', model, flag, out],
                           input=text, text=True, capture_output=True)
        if r.returncode == 0 and os.path.exists(out) and os.path.getsize(out) > 1000:
            return
        err = r.stderr
    sys.exit(f'Piper a échoué pour : {text[:50]}\n{err[-800:]}')

def main():
    story, out = sys.argv[1], sys.argv[2]
    meta = json.load(open(os.path.join(story, 'meta.json'), encoding='utf-8'))
    model = voice_files(meta['voice'], 'voices')
    os.makedirs(out, exist_ok=True)
    for line in open(os.path.join(story, 'SHOTS.txt'), encoding='utf-8'):
        if '|' not in line: continue
        key, text = [x.strip() for x in line.split('|', 1)]
        synth(model, text, os.path.join(out, f'{key}.wav'))
        print('ok', key, flush=True)

if __name__ == '__main__':
    main()
