# La guerre des émeus (Australie, 1932) — script Short

Public : adultes français curieux. Durée visée : 55-65 s. Voix off en français. Pas de CTA (non demandé).
Mention à mettre dans la description : « Personnages et scènes dessinés : mise en scène illustrative d'un fait réel. »

## Tableau des plans
| # | Clé | Lieu | Texte dit | À l'écran |
|---|---|---|---|---|
| 1 | hook | Plaine rouge | En mille neuf cent trente-deux, l'armée australienne a tiré près de dix mille balles sur des oiseaux. | Mitrailleuse sur trépied, émeus au loin |
| 2 | farm | Ferme, champs de blé | Vous voyez, dans l'ouest du pays, d'anciens soldats cultivaient du blé, en pleine crise. | Fermiers en chapeau, blé, journal « crise » |
| 3 | emus | Champs | Puis vingt mille émeus ont ravagé les champs et cassé les clôtures. | Troupeau d'émeus, clôture qui tombe, compteur « 20 000 » |
| 4 | ask | Bureau | Ils ont réclamé ce qu'ils connaissaient de la guerre : des mitrailleuses. | Délégation d'anciens soldats devant un bureau |
| 5 | yes | Bureau du ministre | Le ministre a dit oui : deux mitrailleuses, dix mille cartouches, et un major. | Caisses de cartouches « 10 000 », deux armes, un major |
| 6 | fire | Plaine, camion | En novembre, les soldats ont tiré. Mais les oiseaux se dispersaient en petits groupes. | Camion, tir, émeus qui partent dans tous les sens |
| 7 | press | Rédaction de journal | Les journaux se sont moqués. Les troupes sont parties, puis revenues quelques jours après. | Journaux moqueurs, camion qui part, puis revient |
| 8 | report | Tente de campagne | Au bout d'un mois, le major a rendu son rapport : neuf cent quatre-vingt-six oiseaux tués. Dix balles par oiseau. | Rapport sur une table, « 986 », « 10 balles = 1 oiseau » |
| 9 | why | Plaine | Vous voyez, une mitrailleuse vise un groupe. C'est comme ramasser des billes qui roulent partout. | Billes qui roulent, émeus qui se séparent |
| 10 | so | Camp | Alors le major a admis que les oiseaux étaient solides, et trop rapides. | Major qui regarde l'horizon, émeu qui court |
| 11 | again | Ferme | Les fermiers ont redemandé l'armée. Réponse : non. | Courrier tamponné « NON » |
| 12 | end | Champs clôturés | Finalement, l'armée a rangé ses mitrailleuses. Les émeus, eux, sont toujours là. | Mitrailleuses remises dans leurs caisses, un émeu qui regarde la caméra |

## Carte des faits (deux sources : Wikipédia EN « Emu War » + Slate.fr)
| Affirmation dans le script | Source 1 (Wikipédia EN) | Source 2 (Slate.fr) | Statut |
|---|---|---|---|
| 1932, ouest de l'Australie | Oct-déc. 1932 | « 1932 » | Confirmé |
| Anciens soldats fermiers, crise économique | Beaucoup d'anciens combattants sur terres marginales | Fermiers touchés par la Grande Dépression | Confirmé |
| Environ 20 000 émeus | Environ 20 000 | Environ 20 000 | Confirmé (ordre de grandeur, sans source précise) |
| Dégâts : champs, clôtures | Cultures détruites, clôtures abîmées | Pertes de récoltes | Confirmé |
| Anciens soldats demandent des mitrailleuses | Délégation au ministre Pearce | Délégation d'anciens soldats | Confirmé |
| Ministre dit oui ; 2 mitrailleuses ; 10 000 cartouches ; major Meredith | Pearce ; 2 fusils-mitrailleurs Lewis ; 10 000 cartouches ; Meredith | Mitrailleuses, major Meredith | Confirmé |
| Début des tirs en novembre | 2 novembre 1932 | Non daté | Source 1 + chronologie |
| Oiseaux dispersés en petits groupes | Dispersion de type guérilla (Serventy) | Plus rapides et malins que prévu | Confirmé |
| Moqueries de la presse, retrait puis retour | Retrait le 8 nov., reprise approuvée le 12 nov. | Cessez-le-feu demandé, presse moqueuse | Confirmé |
| 986 oiseaux, 9 860 balles, dix balles par oiseau | Rapport final de Meredith : 986 pour 9 860 | Mêmes chiffres | Confirmé comme chiffre du rapport du major |
| Major admet la résistance des oiseaux | Louange de leur robustesse et agilité | Impressionné par leur résistance | Confirmé (paraphrase, pas de citation) |
| Les fermiers redemandent l'armée, refus | Demandes refusées (1934, 1943, 1948) | Habitants tentent de la faire revenir, gouvernement refuse | Confirmé |
| L'armée range ses mitrailleuses ; les émeus sont toujours là | Impact minimal sur la population ; aucun retour de l'armée | Armée reconnaît sa défaite ; émeus plus nombreux qu'avant | Confirmé |

## Laissé de côté volontairement
- « 2 500 oiseaux blessés » : très contesté (chiffre probablement gonflé, selon Greg Beyer).
- « L'armée a perdu la guerre » : formule populaire, pas un fait. Le script dit seulement que l'opération n'a pas résolu le problème.
- La répartition « 986 tués = seconde phase » (Slate) : contredite par Wikipédia, qui l'attribue au rapport final de la campagne. Le script ne dit donc que « le rapport du major ».
- Primes et clôtures (source unique) : retirées du texte.
- Loi de protection de 1999 : non retrouvée dans la source croisée.
- Aucune citation inventée. Meredith est montré comme un officier respectable, pas comme un méchant.

## Mots à surveiller
- « Mitrailleuses » : les armes étaient des Lewis, fusils-mitrailleurs. Terme grand public conservé.
- « Les émeus sont toujours là » : vrai en général, sans chiffre.
- Hook : « près de dix mille balles » = 9 860 balles du rapport.
