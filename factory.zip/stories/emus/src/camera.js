import * as THREE from 'three';
import timing from './timing.json';

export function warpU(T, t) {
  const n = T.length; if (t <= T[0]) return 0; if (t >= T[n - 1]) return 1;
  const sec = []; for (let i = 0; i < n - 1; i++) sec.push((1 / (n - 1)) / (T[i + 1] - T[i]));
  const m = [0]; for (let i = 1; i < n - 1; i++) m.push(2 * sec[i - 1] * sec[i] / (sec[i - 1] + sec[i])); m.push(0);
  let i = 0; while (t > T[i + 1]) i++;
  const h = T[i + 1] - T[i], x = (t - T[i]) / h, x2 = x * x, x3 = x2 * x;
  return (2 * x3 - 3 * x2 + 1) * (i / (n - 1)) + (x3 - 2 * x2 + x) * h * m[i] + (-2 * x3 + 3 * x2) * ((i + 1) / (n - 1)) + (x3 - x2) * h * m[i + 1];
}

const S = Object.fromEntries(timing.shots.map((s) => [s.key, s]));
const keys = timing.shots.map((s) => s.key);
export const CUTS = keys.map((k, i) => (i === 0 ? 0 : (timing.shots[i - 1].end + timing.shots[i].start) / 2));
export const END = timing.duration;
export const wordT = (key, idx) => S[key].start + (S[key].end - S[key].start) * idx / S[key].words;

export const LIGHTS = {
  night: {sun: '#a9b8ff', si: 1.0, sky: '#4a50a0', gnd: '#2a2030', hi: 1.0, fog: '#232856', near: 120, far: 420, sunOff: [-40, 90, 50], shadow: 70, top: '#0b1030', hor: '#3e3f86', pt: null},
  day: {sun: '#fff0cf', si: 2.6, sky: '#a9d8ff', gnd: '#d9a878', hi: 1.15, fog: '#cfe7f7', near: 160, far: 650, sunOff: [-50, 90, 60], shadow: 80, top: '#3d8fe0', hor: '#cde9f8', pt: null},
  storm: {sun: '#cdd3de', si: 1.1, sky: '#8a95a6', gnd: '#4a4f58', hi: 1.0, fog: '#66738a', near: 45, far: 260, sunOff: [-40, 80, 40], shadow: 80, top: '#3c4454', hor: '#7d889a', pt: null},
  office: {sun: '#fff4e4', si: 1.6, sky: '#f4fbff', gnd: '#b48a62', hi: 1.05, fog: '#efe2cb', near: 30, far: 90, sunOff: [-6, 9, 7], shadow: 10, top: '#7fb7e6', hor: '#d6ecf6', pt: {c: '#ffc77a', i: 7, p: [-2.5, 3.6, 0.5], d: 14}},
  yard: {sun: '#ffe7bd', si: 2.5, sky: '#b5dcff', gnd: '#d1ad7c', hi: 1.15, fog: '#e8d9c0', near: 70, far: 300, sunOff: [-14, 22, 14], shadow: 24, top: '#3d8fe0', hor: '#f0dcc0', pt: null},
  outback: {sun: '#ffe2b0', si: 2.6, sky: '#b5dcff', gnd: '#d98a5a', hi: 1.15, fog: '#f1d8b8', near: 80, far: 320, sunOff: [-16, 26, 16], shadow: 30, top: '#3d8fe0', hor: '#f4dcc0', pt: null},
  weather: {sun: '#eef2ff', si: 1.4, sky: '#eef3f6', gnd: '#8f7b66', hi: 1.1, fog: '#e3e7e1', near: 30, far: 90, sunOff: [-6, 9, 7], shadow: 10, top: '#56606e', hor: '#9aa4b0', pt: {c: '#ffd58a', i: 5, p: [0, 3.8, 0], d: 14}},
  morning: {sun: '#ffbf7a', si: 2.5, sky: '#ffe0bd', gnd: '#c08a5a', hi: 1.0, fog: '#f6d9b8', near: 160, far: 650, sunOff: [-60, 40, 50], shadow: 80, top: '#6fa6dd', hor: '#ffd3a1', pt: null},
};

const v = (a) => new THREE.Vector3(...a);
const L = {hook: 0, fire: 100, why: 200, farm: 300, so: 400, end: 500, office: 600, news: 700, tent: 800};
const k = (ox, p, l) => ({p: [ox + p[0], p[1], p[2]], l: [ox + l[0], l[1], l[2]]});
export const PLAN = {
  hook: {light: 'outback', anchor: [L.hook, 0, 0], keys: [k(L.hook, [1.6, 1.2, 6.5], [0, 1.1, -12]), k(L.hook, [0.9, 1.15, 4.2], [0, 1.1, -13]), k(L.hook, [0.3, 1.1, 2.6], [0, 1.15, -14])]},
  farm: {light: 'day', anchor: [L.farm, 0, 0], keys: [k(L.farm, [-4.2, 1.5, 6.4], [-0.5, 1.4, 0.4]), k(L.farm, [-2.0, 1.55, 5.0], [0.2, 1.4, 0.4]), k(L.farm, [0.4, 1.6, 4.0], [0.8, 1.45, 0.4])]},
  emus: {light: 'day', anchor: [L.farm, 0, -10], keys: [k(L.farm, [-1.0, 1.4, 5.5], [0.5, 1.5, -22]), k(L.farm, [0.2, 1.5, 3.6], [0.4, 1.4, -26]), k(L.farm, [1.4, 1.8, 2.4], [0.2, 1.4, -30])], beats: 'words:emus:0,3,10'},
  ask: {light: 'office', anchor: [L.office, 0, 0], keys: [k(L.office, [-3.6, 1.8, 4.8], [-0.4, 1.5, 0.5]), k(L.office, [-1.8, 1.8, 4.5], [0.0, 1.5, 0.6]), k(L.office, [0.2, 1.8, 4.1], [0.3, 1.5, 0.6])]},
  yes: {light: 'office', anchor: [L.office, 0, 0], keys: [k(L.office, [3.0, 1.9, 4.4], [0.4, 1.3, -1.0]), k(L.office, [1.4, 1.8, 3.9], [0.2, 1.3, -1.1]), k(L.office, [-0.8, 1.8, 3.6], [0.4, 1.3, -1.0])], beats: 'words:yes:0,7,13'},
  fire: {light: 'outback', anchor: [L.fire, 0, 0], keys: [k(L.fire, [3.4, 1.7, 6.0], [-0.5, 1.2, -6]), k(L.fire, [1.8, 1.5, 4.6], [0.0, 1.2, -12]), k(L.fire, [-0.6, 1.8, 4.2], [-1.0, 1.3, -18])], beats: 'words:fire:0,6,15'},
  press: {light: 'weather', anchor: [L.news, 0, 0], keys: [k(L.news, [-3.6, 1.9, 4.2], [-1.0, 2.2, -5.0]), k(L.news, [-1.4, 2.0, 3.4], [1.0, 2.4, -5.2]), k(L.news, [1.6, 2.0, 2.8], [2.6, 2.4, -5.2])]},
  report: {light: 'weather', anchor: [L.tent, 0, 0], keys: [k(L.tent, [-1.8, 1.8, 3.0], [-0.4, 1.6, -1.8]), k(L.tent, [-0.6, 1.8, 2.5], [0.1, 1.8, -2.0]), k(L.tent, [0.8, 1.85, 2.2], [0.5, 1.9, -2.2])], beats: 'words:report:0,11,20'},
  why: {light: 'outback', anchor: [L.why, 0, 0], keys: [k(L.why, [-1.6, 0.9, 5.0], [0.6, 0.3, 0.5]), k(L.why, [-0.2, 0.65, 3.8], [0.8, 0.3, -1.0]), k(L.why, [1.4, 1.3, 3.4], [-0.5, 1.1, -12])], beats: 'words:why:0,9,15'},
  so: {light: 'outback', anchor: [L.so, 0, 0], keys: [k(L.so, [-3.2, 1.6, 6.0], [0.4, 1.4, 0.0]), k(L.so, [-0.6, 1.7, 4.8], [0.2, 1.4, -0.4]), k(L.so, [2.4, 1.8, 4.4], [0.0, 1.4, -0.4])]},
  again: {light: 'day', anchor: [L.farm + 40, 0, 0], keys: [k(L.farm + 40, [-2.8, 1.5, 4.8], [0.2, 1.4, 0.4]), k(L.farm + 40, [-0.8, 1.55, 3.9], [1.0, 1.5, 0.5]), k(L.farm + 40, [1.0, 1.7, 3.4], [1.6, 1.6, 0.5])], beats: 'words:again:0,5,8'},
  end: {light: 'morning', anchor: [L.end, 0, 0], keys: [k(L.end, [-3.0, 1.5, 6.2], [0.0, 1.2, 0.0]), k(L.end, [-0.4, 1.6, 4.6], [1.4, 1.5, -1.4]), k(L.end, [0.9, 1.7, 3.2], [1.5, 1.6, -1.4])], beats: 'words:end:0,8,15'},
};

const CURVES = {};
keys.forEach((key, i) => {
  const P = PLAN[key];
  const a = CUTS[i], b = i + 1 < keys.length ? CUTS[i + 1] : END;
  let T;
  if (P.beats && P.beats.startsWith('words:')) {
    const [, kk, idx] = P.beats.split(':');
    T = idx.split(',').map(Number).map((n) => wordT(kk, n));
    T[0] = a; T[T.length - 1] = b;
  } else T = P.keys.map((_, j) => a + (b - a) * j / (P.keys.length - 1));
  CURVES[key] = {
    p: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.p)), false, 'centripetal'),
    l: new THREE.CatmullRomCurve3(P.keys.map((q) => v(q.l)), false, 'centripetal'),
    T, a, b,
  };
});

export function shotAt(t) {
  let i = 0; while (i + 1 < CUTS.length && t >= CUTS[i + 1]) i++;
  return keys[i];
}
export function cameraAt(t) {
  const key = shotAt(t); const C = CURVES[key];
  const u = warpU(C.T, t);
  return {key, pos: C.p.getPointAt(u), look: C.l.getPointAt(u), plan: PLAN[key], a: C.a, b: C.b};
}
const CONT = new Set([]);
export function dipAt(t) {
  let o = 0;
  keys.forEach((key, i) => {
    if (i === 0 || CONT.has(key)) return;
    const c = CUTS[i]; const d = Math.abs(t - c);
    if (d < 0.2) o = Math.max(o, 1 - d / 0.2);
  });
  return o;
}
