import * as THREE from 'three';
import {INK, rng, toon, box, cyl, sign, ground, cloud, crate, ink, paintTex, facade} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';
import * as P from './props.js';

// positions (x offset) of every place in the story
export const LOC = {hook: 0, fire: 100, why: 200, farm: 300, so: 400, end: 500, office: 600, news: 700, tent: 800};

export const ease = (t, a, b) => { const x = Math.min(1, Math.max(0, (t - a) / (b - a))); return x * x * (3 - 2 * x); };
const sg = (text, w, h, bg = '#f2e6cc', font = 'bold 110px Arial, sans-serif', cw = 640, ch = 256) => sign(text, w, h, {bg, w: cw, h: ch, font});
const pop = (o, t, a, d = 0.45) => { const s = Math.max(0.001, ease(t, a, a + d)); o.visible = t > a; o.scale.setScalar(s); };

// ---------- the emu: flat colours, thick ink, long legs ----------
function emu(seed = 1) {
  const r = rng(seed);
  const root = new THREE.Group(); const body = new THREE.Group(); root.add(body);
  const bc = ['#6f5a47', '#76604b', '#695544'][seed % 3];
  const b = new THREE.Mesh(new THREE.SphereGeometry(0.5, 16, 12), toon(bc)); b.scale.set(1.15, 0.8, 0.8); b.position.y = 1.1; ink(b, 0.035, false); body.add(b);
  const tail = new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 10), toon('#574437')); tail.position.set(-0.55, 1.08, 0); ink(tail, 0.03, false); body.add(tail);
  const neck = new THREE.Group(); neck.position.set(0.5, 1.28, 0); neck.rotation.z = -0.28; body.add(neck);
  neck.add(cyl(0.05, 0.08, 0.85, '#8d97a6', {y: 0.42, seg: 8, thick: 0.02}));
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 10), toon('#8d97a6')); head.position.set(0.02, 0.9, 0); ink(head, 0.02, false); neck.add(head);
  const beak = cyl(0.01, 0.045, 0.2, '#3a3330', {seg: 8, thick: 0.01}); beak.rotation.z = -Math.PI / 2; beak.position.set(0.16, 0.88, 0); neck.add(beak);
  for (const z of [-0.085, 0.085]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 6), new THREE.MeshBasicMaterial({color: '#e0a33a'})); e.position.set(0.07, 0.93, z); neck.add(e); const p = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 5), new THREE.MeshBasicMaterial({color: INK})); p.position.set(0.085, 0.93, z * 1.1); neck.add(p); }
  const legs = [];
  for (const z of [-0.17, 0.17]) {
    const lg = new THREE.Group(); lg.position.set(0.05, 0.85, z);
    lg.add(cyl(0.04, 0.05, 0.85, '#8a7f74', {y: -0.42, seg: 6, thick: 0.02}));
    lg.add(box(0.34, 0.05, 0.1, '#5e554c', {x: 0.1, y: -0.85, thick: 0.015}));
    body.add(lg); legs.push(lg);
  }
  const blob = new THREE.Mesh(new THREE.CircleGeometry(0.6, 20), new THREE.MeshBasicMaterial({color: '#000', transparent: true, opacity: 0.2, depthWrite: false}));
  blob.rotation.x = -Math.PI / 2; blob.position.y = 0.02; blob.scale.y = 0.6; root.add(blob);
  const ph = r() * 6;
  // speed 0 = standing (head bobs a little), >0 = running
  root.userData.step = (t, speed) => {
    const f = speed > 0 ? 9 + speed * 0.4 : 1.2;
    const A = speed > 0 ? 0.7 : 0.03;
    legs[0].rotation.z = Math.sin(t * f + ph) * A; legs[1].rotation.z = -Math.sin(t * f + ph) * A;
    body.position.y = speed > 0 ? Math.abs(Math.sin(t * f + ph)) * 0.09 : 0;
    neck.rotation.z = -0.28 + Math.sin(t * (speed > 0 ? f * 0.5 : 1.7) + ph) * (speed > 0 ? 0.08 : 0.06);
  };
  root.scale.setScalar(1.25);
  root.userData.face = (dx, dz) => { root.rotation.y = Math.atan2(-dz, dx); };
  return root;
}

// ---------- Lewis gun on a tripod, pointing to -z ----------
function lewis() {
  const g = new THREE.Group();
  for (const [x, z] of [[-0.5, 0.5], [0.5, 0.5], [0, -0.55]]) { const l = cyl(0.025, 0.03, 1.05, '#3a3d42', {seg: 6, thick: 0.012}); l.position.set(x * 0.55, 0.52, z * 0.55); l.rotation.z = -x * 0.5; l.rotation.x = z * 0.5; g.add(l); }
  const bar = cyl(0.045, 0.05, 1.4, '#4a4f55', {seg: 10, thick: 0.015}); bar.rotation.x = Math.PI / 2; bar.position.set(0, 1.05, -0.4); g.add(bar);
  const jacket = cyl(0.075, 0.075, 0.7, '#6b7077', {seg: 10, thick: 0.015}); jacket.rotation.x = Math.PI / 2; jacket.position.set(0, 1.05, -0.2); g.add(jacket);
  const drum = cyl(0.17, 0.17, 0.09, '#2f3237', {seg: 14, thick: 0.015}); drum.position.set(0, 1.22, -0.05); g.add(drum);
  g.add(box(0.1, 0.12, 0.35, '#2f3237', {y: 1.0, z: 0.45, thick: 0.012}));
  const flash = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.7, 8), new THREE.MeshBasicMaterial({color: '#ffd45a'})); flash.rotation.x = -Math.PI / 2; flash.position.set(0, 1.05, -1.4); flash.visible = false; g.add(flash);
  g.userData.flash = flash; return g;
}

function room(ox, {w = 14, h = 5, d = 10, wall = '#efe0c4', floor = '#a7764e', seed = 4} = {}) {
  const g = new THREE.Group();
  const wt = paintTex(wall, {seed, stains: 14}); wt.repeat.set(2, 1);
  const walls = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon('#ffffff', wt, {side: THREE.BackSide}));
  walls.position.set(ox, h / 2, 0); walls.receiveShadow = true; g.add(walls);
  const ft = paintTex(floor, {seed: seed + 1}); ft.repeat.set(3, 2);
  const fl = new THREE.Mesh(new THREE.BoxGeometry(w - 0.02, 0.1, d - 0.02), toon('#ffffff', ft)); fl.position.set(ox, 0.0, 0); fl.receiveShadow = true; g.add(fl);
  return g;
}

function wheat(x0, x1, z0, z1, n, seed) {
  const geo = new THREE.BoxGeometry(0.14, 0.95, 0.14);
  const m = new THREE.InstancedMesh(geo, toon('#ffffff'), n); const r = rng(seed); const o = new THREE.Object3D(); const c = new THREE.Color();
  for (let i = 0; i < n; i++) {
    o.position.set(x0 + r() * (x1 - x0), 0.42 + r() * 0.1, z0 + r() * (z1 - z0)); o.scale.set(1, 0.85 + r() * 0.5, 1); o.rotation.set((r() - 0.5) * 0.15, r() * 3, (r() - 0.5) * 0.15); o.updateMatrix(); m.setMatrixAt(i, o.matrix);
    c.set(['#d9ac3f', '#e2b94c', '#c99a32', '#d4a23a'][Math.floor(r() * 4)]); m.setColorAt(i, c);
  }
  m.castShadow = false; m.receiveShadow = false; return m;
}

function bush(x, z, s = 1, seed = 1) {
  const g = new THREE.Group(); const r = rng(seed);
  for (let i = 0; i < 3; i++) { const m = new THREE.Mesh(new THREE.SphereGeometry(0.5 * s * (0.7 + r() * 0.5), 10, 8), toon(['#8a8f4a', '#7b8444', '#99a056'][i])); m.position.set((i - 1) * 0.5 * s, 0.35 * s, (r() - 0.5) * 0.4 * s); ink(m, 0.03, false); g.add(m); }
  g.position.set(x, 0, z); return g;
}
function hills(cx, z, seed) {
  const g = new THREE.Group(); const r = rng(seed);
  for (let i = 0; i < 12; i++) { const h = 8 + r() * 14, rad = 14 + r() * 16; const m = cyl(0, rad, h, ['#a65d3e', '#b3694a', '#9c5638'][i % 3], {x: cx - 110 + i * 20 + r() * 6, y: h / 2, z: z - r() * 20, seg: 7, thick: 0.05}); g.add(m); }
  return g;
}

export function buildWorld() {
  const W = new THREE.Group(); const chars = []; const U = [];
  const addChar = (o, x, y, z) => { o.position.set(x, y, z); W.add(o); chars.push(o); return o; };

  // ======== OUTBACK (red earth) ========
  W.add(ground(1000, 420, '#c0673f', {x: 250, z: -110, seed: 3, repeat: 70}));
  for (const sx of [LOC.hook, LOC.fire, LOC.why, LOC.so, LOC.end]) {
    W.add(hills(sx, -140, sx + 5));
    const r = rng(sx + 9);
    for (let i = 0; i < 26; i++) { const bx = sx - 40 + r() * 80, bz = 4 - r() * 60; if (Math.abs(bx - sx) < 12 && bz > -12) continue; W.add(bush(bx, bz, 0.7 + r() * 1.0, i + sx)); }
    for (let i = 0; i < 7; i++) W.add(P.at(P.tree(1.2 + r() * 0.8, i + sx), sx - 30 + r() * 60, 0.05, -12 - r() * 40));
    for (let i = 0; i < 9; i++) { const rk = new THREE.Mesh(new THREE.SphereGeometry(0.4 + r() * 0.5, 8, 6), toon('#8f6a58')); rk.scale.y = 0.6; rk.position.set(sx - 25 + r() * 50, 0.15, 6 - r() * 30); ink(rk, 0.03, false); W.add(rk); }
  }
  for (let i = 0; i < 12; i++) W.add(cloud(-80 + i * 70, 70 + (i % 3) * 12, -170, 8));

  // --- hook: gun + soldier + herd far away ---
  const gun0 = lewis(); gun0.position.set(LOC.hook + 0.2, 0, 0.6); W.add(gun0);
  addChar(character({palette: 'welder', hat: 'cap', seed: 11}), LOC.hook - 1.3, 0.05, 1.2);
  addChar(character({palette: 'mustard', hat: 'cap', seed: 12}), LOC.hook + 1.9, 0.05, 1.6);
  const post = new THREE.Group(); const ps = sg('OUEST AUSTRALIEN · 1932', 3.4, 1.0, '#e6d39a', 'bold 64px Arial, sans-serif'); ps.position.set(0, 1.9, 0); post.add(ps, cyl(0.06, 0.06, 2.4, '#5a3a26', {y: 1.2, x: -1.4}), cyl(0.06, 0.06, 2.4, '#5a3a26', {y: 1.2, x: 1.4})); post.position.set(LOC.hook + 4.0, 0, -2.0); post.rotation.y = -0.4; W.add(post);
  const crates0 = [crate('MUNITIONS', {x: LOC.hook - 3.2, y: 0.6, z: 0.2, ry: 0.3}), crate('MUNITIONS', {x: LOC.hook - 3.3, y: 1.8, z: 0.25, ry: 0.15})]; crates0.forEach((c) => W.add(c));
  const herdHook = Array.from({length: 11}, (_, i) => { const e = emu(i + 1); const bx = LOC.hook - 8 + (i % 6) * 3.3 + (i > 5 ? 1.6 : 0), bz = -9 - Math.floor(i / 6) * 4 - (i % 3); e.position.set(bx, 0.05, bz); e.userData.face(0.3, 1); W.add(e); return {e, bx, bz}; });
  U.push((t, cam, shot) => { herdHook.forEach(({e, bx, bz}, i) => { e.position.x = bx + Math.sin(t * 0.3 + i) * 0.5; e.userData.step(t, 0); e.userData.face(Math.sin(i), 1); }); });

  // --- fire: truck + gun firing + herd dispersing ---
  const F = LOC.fire;
  const gunF = lewis(); gunF.position.set(F + 0.3, 0, 0.2); W.add(gunF);
  const truckF = P.car('#4f6a41'); truckF.scale.set(1.5, 1.4, 1.3); truckF.position.set(F - 4.4, 0, 2.6); truckF.rotation.y = 0.5; W.add(truckF);
  addChar(character({palette: 'welder', hat: 'cap', seed: 21}), F - 1.1, 0.05, 1.3);
  addChar(character({palette: 'navy', hat: 'cap', seed: 22}), F + 1.9, 0.05, 1.5);
  addChar(character({palette: 'mustard', hat: 'cap', seed: 23}), F - 2.4, 0.05, 0.6);
  const herdF = Array.from({length: 14}, (_, i) => { const e = emu(i + 20); const a = (i / 14) * 6.28; const bx = F - 5 + (i % 5) * 2.6, bz = -9 - Math.floor(i / 5) * 3; W.add(e); return {e, bx, bz, a: -1.2 + (i / 13) * 2.4 + Math.sin(i * 5) * 0.3, sp: 8 + (i % 4) * 2}; });
  U.push((t, cam, shot) => {
    const t0 = wordT('fire', 7);
    const f = shot === 'fire' ? Math.sin(t * 38) > 0 && t > wordT('fire', 0) && t < wordT('fire', 7) + 1.2 : false;
    gunF.userData.flash.visible = f;
    herdF.forEach(({e, bx, bz, a, sp}) => {
      const s = Math.max(0, t - t0);
      const dx = Math.sin(a), dz = -Math.cos(a);
      e.position.set(bx + dx * sp * s * 0.55, 0.05, bz + dz * sp * s * 0.55 - (1 - Math.min(1, s)) * 0);
      if (s > 0) e.userData.face(dx, dz); else e.userData.face(0.3, 1);
      e.userData.step(t, s > 0 ? sp : 0);
    });
  });

  // --- why: marbles + emus that split ---
  const Y = LOC.why;
  const marbles = Array.from({length: 46}, (_, i) => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 10), toon(['#c43d32', '#2f6db3', '#4f8a4a', '#e0b04a', '#7a4f73', '#f7f0de'][i % 6])); ink(m, 0.01, false); W.add(m); const a = i * 2.399; return {m, a, d: 2.2 + (i % 7) * 0.55}; });
  const gunW = lewis(); gunW.position.set(Y - 3.5, 0, -2.0); gunW.rotation.y = 0.5; W.add(gunW);
  const herdW = Array.from({length: 12}, (_, i) => { const e = emu(i + 40); W.add(e); return {e, bx: Y - 3 + (i % 4) * 1.5, bz: -7 - Math.floor(i / 4) * 1.8, a: -1.4 + (i / 11) * 2.8, sp: 4 + (i % 4) * 1.2}; });
  U.push((t, cam, shot) => {
    const tm = wordT('why', 11), ts = wordT('why', 6);
    marbles.forEach(({m, a, d}, i) => { const s = ease(t, tm, tm + 1.6); const rr = 0.25 + (i % 5) * 0.12 + s * d; m.position.set(Y + 0.6 + Math.cos(a) * rr * 0.9, 0.11, 0.5 + Math.sin(a) * rr * 0.55); });
    herdW.forEach(({e, bx, bz, a, sp}) => {
      const s = Math.max(0, t - ts) * (shot === 'why' ? 1 : 0); const dx = Math.sin(a), dz = -Math.cos(a) * 0.7 - 0.2;
      e.position.set(bx + dx * sp * s * 0.5, 0.05, bz + dz * sp * s * 0.5);
      if (s > 0.05) e.userData.face(dx, dz); else e.userData.face(0.2, 1);
      e.userData.step(t, s > 0.05 ? sp : 0);
    });
  });

  // --- so: camp, major, emu running past ---
  const S = LOC.so;
  const tentO = new THREE.Mesh(new THREE.ConeGeometry(3.2, 2.6, 4), toon('#d8c9a2')); tentO.position.set(S + 5.2, 1.3, -3); tentO.rotation.y = Math.PI / 4; ink(tentO, 0.04, true); W.add(tentO);
  W.add(P.at(P.barrel('#4f6a41'), S - 3.2, 0.05, -1.2), P.at(P.barrel('#c43d32'), S - 2.5, 0.05, -1.8), crate('MUNITIONS', {x: S - 4.4, y: 0.6, z: -0.8, ry: 0.2}));
  const major = addChar(character({palette: 'navy', hat: 'cap', glasses: true, seed: 31}), S + 0.2, 0.05, 0.4);
  addChar(character({palette: 'welder', hat: 'cap', seed: 32}), S - 1.8, 0.05, 1.0);
  const gunS = lewis(); gunS.position.set(S + 2.4, 0, -0.2); gunS.rotation.y = -0.6; W.add(gunS);
  const emuS = emu(61); W.add(emuS);
  const herdS = Array.from({length: 5}, (_, i) => { const e = emu(70 + i); W.add(e); return {e, k: i}; });
  U.push((t, cam, shot) => {
    const a = wordT('so', 0), b = wordT('so', 9) + 1.5; const p = Math.min(1, Math.max(0, (t - a) / (b - a)));
    emuS.position.set(S + 10 - 22 * p, 0.05, -2.4); emuS.userData.face(-1, 0.05); emuS.userData.step(t, shot === 'so' ? 12 : 0);
    herdS.forEach(({e, k}) => { const q = Math.min(1, Math.max(0, (t - a - 0.3 * k) / (b - a))); e.position.set(S + 14 - 26 * q, 0.05, -7 - k * 2.2); e.userData.face(-1, 0); e.userData.step(t, shot === 'so' ? 12 : 0); });
    major.userData.armR.rotation.z = shot === 'so' ? 0.5 + ease(t, wordT('so', 2), wordT('so', 4)) * 1.2 : 0;
  });

  // --- end: crates closed, one emu stares at the camera ---
  const E = LOC.end;
  for (let i = 0; i < 3; i++) W.add(crate('ARMÉE', {x: E - 3.4 + i * 1.3, y: 0.6, z: -1.2 + (i % 2) * 0.3, ry: 0.1 * i, s: 1.2}));
  W.add(crate('ARMÉE', {x: E - 2.8, y: 1.8, z: -1.2, ry: -0.1}), P.at(P.fence(14), E - 8, 0.05, -4, 0));
  addChar(character({palette: 'welder', hat: 'cap', seed: 41}), E - 5.2, 0.05, 0.4);
  const emuE = emu(81); emuE.position.set(E + 1.5, 0.05, -0.6); W.add(emuE);
  const emuE2 = emu(82); emuE2.position.set(E + 6, 0.05, -6); W.add(emuE2);
  U.push((t, cam) => {
    emuE.userData.step(t, 0); emuE2.userData.step(t, 0);
    const dx = cam.position.x - emuE.position.x, dz = cam.position.z - emuE.position.z; emuE.userData.face(dx, dz);
    emuE2.userData.face(-1, 0.6);
  });

  // ======== FARM (wheat + broken fence) ========
  const R = LOC.farm;
  W.add(ground(220, 120, '#b98a52', {x: R, z: -20, seed: 14, repeat: 18}));
  W.add(wheat(R - 40, R + 40, -42, -0.5, 8000, 91));
  W.add(wheat(R - 40, R + 40, -42, -0.5, 1, 92));
  const house = facade({w: 9, h: 4.2, color: '#c4a27c', cols: 3, rows: 1, door: true, seed: 5}); house.position.set(R - 14, 0, -44); W.add(house);
  W.add(box(10, 0.3, 6, '#9a4a3a', {x: R - 14, y: 4.4, z: -46.5, thick: 0.04}));
  W.add(hills(R, -110, 7));
  for (let i = 0; i < 12; i++) W.add(cloud(R - 80 + i * 20, 60 + (i % 3) * 10, -130, 7));
  const fenceLine = []; for (let i = 0; i < 10; i++) { const f = P.fence(6); f.position.set(R - 30 + i * 6, 0.05, -2.2); W.add(f); fenceLine.push(f); }
  for (let i = 0; i < 4; i++) W.add(P.at(P.tree(1.3, i + 400), R - 36 + i * 24, 0.05, 8 + (i % 2) * 3));
  const farmers = [['mustard', 'bowler', 61, R - 1.8, 0.2], ['red', 'cap', 62, R + 0.3, 1.0], ['teal', 'bowler', 63, R + 2.2, 0.3]].map(([pal, hat, s, x, z]) => addChar(character({palette: pal, hat, seed: s}), x, 0.05, z));
  const farmSign = sg('BLÉ', 2.2, 1.0, '#e6d39a', 'bold 90px Arial, sans-serif', 440, 200); farmSign.position.set(R + 5.4, 2.4, -1.4); W.add(farmSign, cyl(0.06, 0.06, 2.4, '#5a3a26', {x: R + 4.3, y: 1.2, z: -1.4}), cyl(0.06, 0.06, 2.4, '#5a3a26', {x: R + 6.5, y: 1.2, z: -1.4}));
  const count = sg('20 000', 5.2, 1.7, '#f2e6cc', 'bold 130px Arial, sans-serif', 780, 260); count.position.set(R + 0.5, 4.6, -9); W.add(count, cyl(0.07, 0.07, 4.4, '#3a3a3a', {x: R - 2.0, y: 2.2, z: -9.1}), cyl(0.07, 0.07, 4.4, '#3a3a3a', {x: R + 3.0, y: 2.2, z: -9.1}));
  const herdR = Array.from({length: 16}, (_, i) => { const e = emu(i + 100); W.add(e); return {e, x: R - 7 + (i % 5) * 3.4 + Math.sin(i * 2) * 1.2, z0: -26 - Math.floor(i / 5) * 3.5, sp: 6.5 + (i % 4) * 0.7}; });
  const mb = P.mailbox(); mb.scale.setScalar(1.2); mb.position.set(R + 40, 0.05, 0); W.add(mb);
  const letters = Array.from({length: 3}, (_, i) => { const l = box(0.4, 0.02, 0.28, '#f7f0de', {thick: 0.004, edges: false}); l.position.set(R + 39.4 + i * 0.4, 1.3 + i * 0.03, 1.2); l.rotation.set(0.2, 0.3 * i, 0); W.add(l); return l; });
  const nonSign = sg('NON', 1.6, 0.8, '#f4ead4', 'bold 100px Arial, sans-serif', 480, 240); nonSign.position.set(R + 41.8, 1.9, 0.6); nonSign.children[0].material.forEach((m) => { if (m.color) m.color.set('#ffffff'); }); W.add(nonSign);
  const cm = sg('ARMÉE ?', 1.7, 0.8, '#e6d39a', 'bold 80px Arial, sans-serif', 480, 240); cm.position.set(R + 38.0, 1.9, 0.6); W.add(cm);
  const farmer2 = addChar(character({palette: 'mustard', hat: 'bowler', seed: 66}), R + 38.2, 0.05, 3.0);
  const fence2 = P.fence(10); fence2.position.set(R + 46, 0.05, -1); W.add(fence2);
  U.push((t, cam, shot) => {
    herdR.forEach(({e, x, z0, sp}, i) => {
      const ta = wordT('emus', 0) - 0.3; const s = Math.max(0, t - ta);
      const z = Math.min(-5.6, z0 + s * sp); e.position.set(x + Math.sin(s * 1.3 + i) * 0.7, 0.05, shot === 'emus' || shot === 'farm' ? z : z0); e.userData.face(0, 1);
      e.userData.step(t, shot === 'emus' && z < -5.7 ? sp : 0);
    });
    pop(count, t, wordT('emus', 1), 0.5);
    fenceLine.forEach((f, i) => { const fall = ease(t, wordT('emus', 6), wordT('emus', 9) + 0.4); f.rotation.x = (i === 3 || i === 4 || i === 5 ? 1.0 : 0) * fall; f.position.y = 0.05 - 0.4 * (i === 4 ? fall : 0); });
    pop(nonSign, t, wordT('again', 6), 0.4);
    letters.forEach((l, i) => { l.visible = true; });
    farmers.forEach((c, i) => { c.userData.armR.rotation.z = shot === 'farm' ? 0.4 + Math.sin(t * 3 + i) * 0.1 : 0; });
  });

  // ======== OFFICE (the minister) ========
  const O = LOC.office;
  W.add(room(O, {w: 16, h: 5.5, d: 11, wall: '#bfe0db', seed: 8}));
  const desk = new THREE.Group(); desk.add(box(4.2, 0.18, 1.6, '#8a5a3b', {y: 1.0})); for (const [x, z] of [[-1.9, -0.6], [1.9, -0.6], [-1.9, 0.6], [1.9, 0.6]]) desk.add(box(0.15, 0.95, 0.15, '#6b4430', {x, y: 0.47, z})); desk.position.set(O, 0, -1.2); W.add(desk);
  W.add(P.at(P.rug(7, 4.4, '#a8433a', '#e0b04a'), O, 0, 0.4), P.at(P.chair(), O, 0.05, -2.3, Math.PI), P.at(P.deskLamp(), O + 1.6, 1.09, -1.3), P.at(P.papers(8, 4), O - 1.3, 1.09, -1.1), P.at(P.mug(), O + 0.6, 1.09, -0.9));
  W.add(P.at(P.bookshelf(4), O - 5.4, 0.05, -5.15), P.at(P.bookshelf(5), O + 5.2, 0.05, -5.15), P.at(P.filingCabinet(), O + 7.0, 0.05, -4.8), P.at(P.wallClock(), O + 0.0, 4.6, -5.4));
  const dp = P.poster('DÉFENSE', 1.6, 2.0, '#e6d39a'); P.at(dp, O - 2.6, 3.2, -5.45); W.add(dp);
  const mp = sg('AUSTRALIE', 3.4, 2.2, '#9fc7de', 'bold 70px Arial, sans-serif', 680, 440); P.at(mp, O + 2.8, 3.2, -5.45); W.add(mp);
  for (const x of [O - 3, O + 3]) { W.add(cyl(0.02, 0.02, 0.8, '#2b2b2e', {x, y: 5.1, z: -1})); W.add(cyl(0.15, 0.45, 0.35, '#2f5d62', {x, y: 4.6, z: -1, seg: 14})); const b = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), new THREE.MeshBasicMaterial({color: '#fff1c0'})); b.position.set(x, 4.45, -1); W.add(b); }
  const minister = addChar(character({palette: 'official', hat: 'none', glasses: true, seed: 71}), O, 0.05, -2.0);
  const dele = [['mustard', 'cap', 72, O - 2.2, 1.6], ['teal', 'cap', 73, O - 0.1, 2.3], ['red', 'cap', 74, O + 2.1, 1.5]].map(([pal, hat, s, x, z]) => addChar(character({palette: pal, hat, seed: s}), x, 0.05, z));
  const askSign = sg('MITRAILLEUSES ?', 3.0, 0.8, '#f2e6cc', 'bold 60px Arial, sans-serif', 780, 210); askSign.position.set(O + 0.3, 2.9, -4.6); W.add(askSign);
  const oui = sg('OUI', 1.6, 0.9, '#e6d39a', 'bold 120px Arial, sans-serif', 480, 270); oui.position.set(O - 2.2, 2.7, -1.2); W.add(oui);
  const gunDeskA = lewis(); gunDeskA.scale.setScalar(0.5); gunDeskA.position.set(O - 1.2, 1.1, -1.0); gunDeskA.rotation.y = -0.4; W.add(gunDeskA);
  const gunDeskB = lewis(); gunDeskB.scale.setScalar(0.5); gunDeskB.position.set(O + 0.4, 1.1, -0.9); gunDeskB.rotation.y = 0.4; W.add(gunDeskB);
  const cr = [0, 1, 2].map((i) => crate('CARTOUCHES', {x: O + 3.1 + (i % 2) * 1.0, y: 0.6 + Math.floor(i / 2) * 1.2, z: 0.6 - (i % 2) * 0.3, ry: 0.15 * i})); cr.forEach((c) => W.add(c));
  const tenK = sg('10 000', 2.6, 0.9, '#f2e6cc', 'bold 90px Arial, sans-serif', 640, 220); tenK.position.set(O + 3.6, 2.6, 0.7); W.add(tenK);
  const majorO = addChar(character({palette: 'navy', hat: 'cap', glasses: true, seed: 75}), O + 4.8, 0.05, -1.4);
  U.push((t, cam, shot) => {
    pop(askSign, t, wordT('ask', 7), 0.4);
    pop(oui, t, wordT('yes', 4), 0.35);
    gunDeskA.visible = t > wordT('yes', 6); gunDeskB.visible = gunDeskA.visible;
    cr.forEach((c) => { c.visible = t > wordT('yes', 8); }); tenK.visible = t > wordT('yes', 8); pop(tenK, t, wordT('yes', 8), 0.4);
    majorO.visible = t > wordT('yes', 12);
    minister.userData.armR.rotation.z = shot === 'yes' ? 0.3 : 0;
  });

  // ======== NEWSROOM (the press laughs) ========
  const N = LOC.news;
  W.add(room(N, {w: 16, h: 5.5, d: 11, wall: '#e0d6bd', floor: '#8a6a4e', seed: 18}));
  const heads = ['LES ÉMEUS ?!', 'ARMÉE vs ÉMEUS', 'LA GUERRE DES ÉMEUS', 'ON RIT AU CAFÉ'];
  const papersN = heads.map((h, i) => { const s = sg(h, 2.1, 1.5, '#f4ead4', 'bold 54px Arial, sans-serif', 420, 300); s.position.set(N - 4.8 + i * 3.2, 3.2, -5.35); W.add(s); return s; });
  for (const x of [-4.8, -1.6, 1.6, 4.8]) W.add(P.at(P.desk(2.6, '#7a4f33'), N + x, 0.05, -3.2), P.at(P.papers(6, Math.round(x * 3 + 20)), N + x - 0.3, 1.02, -3.2), P.at(P.phone(), N + x + 0.7, 1.02, -3.2));
  W.add(P.at(P.deskLamp(), N + 2.0, 1.02, -3.4), P.at(P.wallClock(), N - 0.4, 4.7, -5.4), P.at(P.filingCabinet(), N + 7.0, 0.05, -4.7), P.at(P.bookshelf(6, 2.0, 2.4), N - 7.75, 0.05, -1.5, Math.PI / 2));
  const press = new THREE.Group(); press.add(box(2.6, 1.5, 1.3, '#4a5560', {y: 0.75}), cyl(0.5, 0.5, 2.4, '#8d9199', {y: 1.7, x: 0, z: 0, seg: 14}), box(2.2, 0.1, 1.0, '#f7f0de', {y: 1.55, x: 1.5})); press.children[1].rotation.z = Math.PI / 2; press.position.set(N + 5.0, 0.05, 1.8); W.add(press);
  addChar(character({palette: 'clerk', hat: 'bowler', glasses: true, seed: 81}), N - 2.3, 0.05, -1.0);
  addChar(character({palette: 'pink', hat: 'none', seed: 82}), N + 0.2, 0.05, 0.6);
  addChar(character({palette: 'mustard', hat: 'top', seed: 83}), N + 3.0, 0.05, -1.2);
  for (const x of [N - 3, N + 3]) { W.add(cyl(0.02, 0.02, 0.8, '#2b2b2e', {x, y: 5.1, z: -1})); W.add(cyl(0.15, 0.45, 0.35, '#2f5d62', {x, y: 4.6, z: -1, seg: 14})); const b = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), new THREE.MeshBasicMaterial({color: '#fff1c0'})); b.position.set(x, 4.45, -1); W.add(b); }
  U.push((t) => { papersN.forEach((p, i) => pop(p, t, wordT('press', i === 0 ? 1 : i === 1 ? 2 : 4 + i), 0.35)); });

  // ======== TENT (the report) ========
  const T = LOC.tent;
  W.add(room(T, {w: 12, h: 4.6, d: 9, wall: '#d8c9a2', floor: '#a88a5e', seed: 28}));
  const table = new THREE.Group(); table.add(box(3.4, 0.14, 1.5, '#7a4f33', {y: 1.0}), ...[[-1.5, -0.6], [1.5, -0.6], [-1.5, 0.6], [1.5, 0.6]].map(([x, z]) => box(0.12, 0.95, 0.12, '#5a3a26', {x, y: 0.47, z}))); table.position.set(T, 0, -1.3); W.add(table);
  W.add(P.at(P.deskLamp(), T - 1.4, 1.07, -1.4), P.at(P.papers(9, 12), T - 0.5, 1.07, -1.2), P.at(P.mug('#4f6a41'), T + 1.4, 1.07, -1.1));
  const report = sg('RAPPORT', 1.9, 0.6, '#f7f0de', 'bold 60px Arial, sans-serif', 460, 150); report.position.set(T + 0.4, 2.3, -2.4); W.add(report);
  const n986 = sg('986', 2.8, 1.5, '#f2e6cc', 'bold 190px Arial, sans-serif', 560, 300); n986.position.set(T - 1.6, 3.0, -2.6); W.add(n986);
  const tenb = sg('10 BALLES = 1 ÉMEU', 3.6, 1.0, '#e6d39a', 'bold 62px Arial, sans-serif', 720, 200); tenb.position.set(T + 1.9, 2.3, -2.6); W.add(tenb);
  for (let i = 0; i < 4; i++) W.add(crate('MUNITIONS', {x: T + 4.0 + (i % 2) * 1.0, y: 0.6 + Math.floor(i / 2) * 1.2, z: -2.8 + (i % 2) * 0.3, ry: 0.1 * i}));
  W.add(P.at(P.barrel('#4f6a41'), T - 4.6, 0.05, -3.0), P.at(P.barrel('#c43d32'), T - 4.0, 0.05, -3.5), P.at(P.chair(), T, 0.05, -2.45, Math.PI));
  W.add(P.at(P.filingCabinet('#8f7d6a'), T - 5.3, 0.05, -1.4), P.at(P.rug(6, 3.4, '#6b7b4f', '#d9c28a'), T, 0, 0.6));
  const majorT = addChar(character({palette: 'navy', hat: 'cap', glasses: true, seed: 91}), T, 0.05, -2.2);
  addChar(character({palette: 'welder', hat: 'cap', seed: 92}), T - 2.6, 0.05, 0.2);
  U.push((t, cam, shot) => { pop(n986, t, wordT('report', 11), 0.5); pop(tenb, t, wordT('report', 16), 0.45); majorT.userData.armR.rotation.z = shot === 'report' ? 0.2 + ease(t, wordT('report', 9), wordT('report', 11)) * 1.0 : 0; });

  const update = (t, cam, shot) => {
    for (const c of chars) c.userData.update(t, cam.position);
    for (const u of U) u(t, cam, shot);
  };
  return {group: W, update};
}
